package Game_Not_Used.sound.Items.Rarity_Test;

public class ArmorType {

    private String armorName;

    public ArmorType(String armorName){
        this.armorName = armorName;
    }

    public String getArmorName() {
        return armorName;
    }
}
