package Game_Not_Used.sound.Items.Rarity_Test;

public class WeaponType {

    private String weaponName;

    public WeaponType(String weaponName){
        this.weaponName = weaponName;
    }


    public String getWeaponName(){
        return weaponName;
    }
}
