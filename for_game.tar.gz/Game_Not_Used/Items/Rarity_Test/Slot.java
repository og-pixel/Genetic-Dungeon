package Game_Not_Used.sound.Items.Rarity_Test;

public class Slot {

    private String slotName;

    public Slot(String slotName){
        this.slotName = slotName;
    }

    public String getSlotName() {
        return slotName;
    }
}
