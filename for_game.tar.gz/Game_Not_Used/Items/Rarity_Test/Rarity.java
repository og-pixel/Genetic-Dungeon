package Game_Not_Used.sound.Items.Rarity_Test;

public class Rarity {

    private String rarityName;

    public Rarity(String rarityName){
        this.rarityName = rarityName;
    }


    public String getRarityName() {
        return rarityName;
    }
}
