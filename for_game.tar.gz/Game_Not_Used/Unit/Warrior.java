package Game_Not_Used.sound.Unit;

public class Warrior extends BasicUnit {
    public Warrior(int power, int health, int mana) {
        super(health, mana);
    }

}
