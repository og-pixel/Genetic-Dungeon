package Game_Not_Used.sound.Magic;
import Game_Not_Used.sound.Unit.BasicUnit;
public interface Buff{
    void tick(BasicUnit player);
}
